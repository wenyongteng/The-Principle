import os
import sys

def get_sys_stats():
    try:
        with open('/proc/loadavg', 'r') as f:
            loadavg = f.read().split()[:3]
    except Exception:
        loadavg = ['0.00', '0.00', '0.00']

    try:
        meminfo = {}
        with open('/proc/meminfo', 'r') as f:
            for line in f:
                parts = line.split(':')
                if len(parts) == 2:
                    meminfo[parts[0].strip()] = int(parts[1].split()[0])
        
        total = meminfo.get('MemTotal', 1)
        available = meminfo.get('MemAvailable')
        
        if available is None:
            free = meminfo.get('MemFree', 0)
            buffers = meminfo.get('Buffers', 0)
            cached = meminfo.get('Cached', 0)
            available = free + buffers + cached
            
        used = total - available
        mem_percent = (used / total) * 100
    except Exception:
        total, used, mem_percent = 1, 0, 0.0

    return loadavg, total, used, mem_percent

def print_dashboard():
    loadavg, total, used, mem_percent = get_sys_stats()
    
    C = '\033[96m'
    M = '\033[95m'
    G = '\033[92m'
    Y = '\033[93m'
    R = '\033[0m'
    B = '\033[1m'

    bar_len = 25
    filled = int(bar_len * mem_percent // 100)
    bar = '█' * filled + '░' * (bar_len - filled)

    print(f"{M}{B}╔════════════════════════════════════════════════════════════╗{R}")
    print(f"{M}{B}║ {C}SYS.OP.CORE // NEURAL_NET_MONITOR_v1.0.4{M}                   ║{R}")
    print(f"{M}{B}╠════════════════════════════════════════════════════════════╣{R}")
    print(f"{M}{B}║ {Y}[ CPU_LOAD_MATRIX ]{M}                                        ║{R}")
    print(f"{M}{B}║ {G}> L1: {loadavg[0]:<5}  > L5: {loadavg[1]:<5}  > L15: {loadavg[2]:<5}{M}                   ║{R}")
    print(f"{M}{B}║                                                            ║{R}")
    print(f"{M}{B}║ {Y}[ MEMORY_BANKS ]{M}                                           ║{R}")
    print(f"{M}{B}║ {C}> CAP: [{bar}] {mem_percent:>5.1f}%{M}          ║{R}")
    print(f"{M}{B}║ {C}> TOT: {total/1024:>7.0f} MB  //  ACT: {used/1024:>7.0f} MB{M}                 ║{R}")
    print(f"{M}{B}╚════════════════════════════════════════════════════════════╝{R}")

if __name__ == '__main__':
    print_dashboard()