import random

def main():
    # Set random seed for reproducibility
    random.seed(42)

    # Hyperparameters
    alpha = 0.5
    gamma = 0.99
    epsilon = 1.0
    epsilon_decay = 0.95
    min_epsilon = 0.01
    episodes = 200

    # Q-table initialization: 10 states, 2 actions (0: Left, 1: Right)
    q_table = [[0.0, 0.0] for _ in range(10)]

    def get_action(state, eps):
        # Epsilon-greedy exploration
        if random.random() < eps:
            return random.choice([0, 1])
        else:
            # Break ties by preferring Right (1) to encourage forward movement initially
            return 1 if q_table[state][1] >= q_table[state][0] else 0

    def step(state, action):
        # Environment dynamics
        if action == 0:
            next_state = max(0, state - 1)
        else:
            next_state = min(9, state + 1)
            
        # Rewards and terminal conditions
        if next_state == 9:
            reward = 10
            done = True
        elif next_state == 4:
            reward = -10
            done = False
        else:
            # Step penalty to encourage finding the shortest path and prevent infinite loops
            reward = -1
            done = False
            
        return next_state, reward, done

    # Training loop
    for ep in range(episodes):
        state = 0
        done = False
        steps = 0
        
        while not done and steps < 200:
            action = get_action(state, epsilon)
            next_state, reward, done = step(state, action)
            
            # Bellman equation update
            if done:
                target = reward
            else:
                target = reward + gamma * max(q_table[next_state][0], q_table[next_state][1])
                
            q_table[state][action] += alpha * (target - q_table[state][action])
            
            state = next_state
            steps += 1
            
        # Decay epsilon
        epsilon = max(min_epsilon, epsilon * epsilon_decay)

    # Print final Q-table
    print("Final Q-table:")
    for s in range(10):
        print(f"State {s}: Left={q_table[s][0]:.2f}, Right={q_table[s][1]:.2f}")

    # Test simulation
    print("\nTest Simulation (Optimal Path):")
    state = 0
    path = [state]
    steps = 0
    
    while state != 9 and steps < 20:
        # Pure exploitation for testing
        action = 1 if q_table[state][1] >= q_table[state][0] else 0
        action_str = "Right" if action == 1 else "Left"
        
        next_state, reward, done = step(state, action)
        print(f"State {state} -> Action {action_str} -> State {next_state} (Reward: {reward})")
        
        state = next_state
        path.append(state)
        steps += 1

    print(f"Final Path: {path}")

if __name__ == "__main__":
    main()