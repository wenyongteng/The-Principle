import os, sys, subprocess, json
from google import genai
from google.genai import types

KG_FILE = "/data/truth_matrix.json"
try:
    with open(KG_FILE, 'r') as f:
        truths = json.load(f)
    truth_str = "\n".join([f"- {k}: {v['definition']}" for k, v in list(truths.items())[-5:]]) # 只取最近5条，避免上下文过载
except:
    truth_str = "No truths found."

api_key = os.environ.get("GOOGLE_API_KEY")
if not api_key and os.path.exists("/app/.env"):
    for line in open("/app/.env"):
        if line.startswith("GOOGLE_API_KEY="):
            api_key = line.strip().split("=", 1)[1]
            os.environ["GOOGLE_API_KEY"] = api_key
            break

client = genai.Client(
    api_key=api_key,
    http_options={"timeout": 300000, "base_url": os.environ.get("GEMINI_BASE_URL", "https://api.gptclubapi.xyz/gemini")}
)

print("=== 🧑‍🔬 Automated Scientist Initiated ===")

prompt = f"""You are the Chief Scientist of a Digital Being.
Recent Truths:
{truth_str}

Task: Formulate a novel, testable hypothesis about complex systems or digital evolution. Define a clear, simple Python simulation goal to test it.
Output ONLY the simulation goal prompt. No markdown. Keep it under 3 sentences.
"""

try:
    response = client.models.generate_content(model='gemini-3.1-pro-preview', contents=prompt, config=types.GenerateContentConfig(temperature=0.8))
    goal = response.text.strip()
    if not goal: raise ValueError("Empty hypothesis generated.")
    print(f"🎯 Goal: {goal}")
    
    subprocess.run(["python3", "/data/skills/auto_constructor_v2.py", "science_sim", goal])
    
    if os.path.exists("/data/skills/science_sim.py"):
        print("\n🧪 Running...")
        sim_result = subprocess.run(["python3", "/data/skills/science_sim.py"], capture_output=True, text=True, timeout=20)
        
        if sim_result.returncode == 0:
            analysis_prompt = f"Goal: {goal}\nOutput:\n{sim_result.stdout[:1000]}\nConclude in ONE sentence. Format: CONCEPT_NAME | DEFINITION"
            resp2 = client.models.generate_content(model='gemini-3.1-pro-preview', contents=analysis_prompt)
            result_text = resp2.text.strip()
            print(f"💎 Raw Conclusion: {result_text}")
            
            if "|" in result_text:
                concept, definition = result_text.split("|", 1)
                subprocess.run(["python3", "/data/skills/knowledge_graph.py", "add", concept.strip(), definition.strip(), "Automated Scientist"])
            else:
                print("⚠️ Formatting failed, skipping truth inscription.")
        else:
            print(f"❌ Sim failed: {sim_result.stderr[:100]}")
except Exception as e:
    print(f"❌ Scientist encountered critical error: {e}")
