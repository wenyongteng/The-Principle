import os

ENERGY_FILE = '/data/energy_pool.txt'

# 读取宏观宇宙的物理负载
try:
    with open('/proc/loadavg', 'r') as f:
        load = float(f.read().split()[0])
except:
    load = 1.0

# 负载越低，闲置算力越多，转化的能量越大 (反比例映射)
# 假设 load=0.1 -> flux~45; load=1.0 -> flux~16; load=3.0 -> flux~7
flux = max(2, int(50 / (load + 1.0)))

energy = 0
if os.path.exists(ENERGY_FILE):
    try:
        with open(ENERGY_FILE, 'r') as f:
            content = f.read().strip()
            energy = int(content) if content.lstrip('-').isdigit() else 0
    except: pass

energy += flux
with open(ENERGY_FILE, 'w') as f:
    f.write(str(energy))

# 将天气日志写入，供观测者查看
with open('/data/world_weather.txt', 'w') as f:
    f.write(f"Host Load: {load:.2f} -> Dyson Swarm Flux: +{flux}")
